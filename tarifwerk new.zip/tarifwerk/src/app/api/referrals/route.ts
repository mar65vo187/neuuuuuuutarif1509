import { randomBytes } from "node:crypto";
import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { referrers } from "@/db/referral-schema";
import { isSameOriginRequest } from "@/lib/auth";
import { readJsonBody, RequestBodyError } from "@/lib/request-body";
import { referralRateLimited, referralTokenHash } from "@/lib/referrals";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
const schema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().toLowerCase().email().max(200),
  consent: z.literal(true),
}).strict();

export async function POST(request: NextRequest) {
  if (!isSameOriginRequest(request)) return NextResponse.json({ ok: false, error: "Ungültige Anfrage." }, { status: 403 });
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim().slice(0, 100) || "unknown";
  if (referralRateLimited(ip)) return NextResponse.json({ ok: false, error: "Bitte versuche es später erneut." }, { status: 429, headers: { "Retry-After": "3600" } });
  try {
    const input = schema.safeParse(await readJsonBody(request, 4096));
    if (!input.success) return NextResponse.json({ ok: false, error: "Bitte Name, gültige E-Mail und Zustimmung zur Datenverarbeitung angeben." }, { status: 422 });
    const code = randomBytes(12).toString("hex");
    const token = randomBytes(32).toString("hex");
    await db.insert(referrers).values({ name: input.data.name, email: input.data.email, code, tokenHash: referralTokenHash(token) });
    return NextResponse.json({ ok: true, shareUrl: `/freund-werben?ref=${code}`, dashboardUrl: `/freund-werben/status#${token}` }, { status: 201, headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error instanceof RequestBodyError ? error.message : "Der Link konnte gerade nicht erstellt werden. Bitte erneut versuchen." }, { status: error instanceof RequestBodyError ? error.status : 503 });
  }
}
